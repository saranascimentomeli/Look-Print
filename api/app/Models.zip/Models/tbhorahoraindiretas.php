<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbhorahoraindiretas extends Model
{
    use HasFactory;
    protected $table = 'tbhorahoraindiretas';
    protected $fillable = ['tipoprocesso', 'tempoprocesso', 'data', 'cad', 'hora'];
}
