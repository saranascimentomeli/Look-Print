<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\slaatributos;

class slahoradecortes extends Model
{
    use HasFactory;
    protected $table = 'slahoradecortes';
    protected $fillable = [
        'id', 'ETD', 'Planning', 'Picking', 'Consolidation', 'Packing', 'Shipping', 'huclose', 'cad'
    ];


    public function __construct()
    {
    }




    public function MontarVencimento($horariosdecorte, $timeEtd, $processo, $totalPedidos, $totalPententes, $Historicodecorte, $dataEtd, $diaNumero)
    {

        date_default_timezone_set('America/Sao_Paulo');
        if ($diaNumero == 2)
            $diaNumero = -1;

        $resultadoHoraETD = array_filter($horariosdecorte->toArray(), function ($valor) use ($timeEtd) {

            if ($valor->ETD == $timeEtd) {
                return $valor;
            }
        });



        $id = $dataEtd . ' ' . $timeEtd . ' ' . $processo;
        $resultadoHistorico = array_filter($Historicodecorte->toArray(), function ($valor) use ($id) {

            if ($valor->id == $id) {
                return $valor;
            }
        });

        $SlaSalvo = '';
        $SlaSalvonum = '';
        if (count($resultadoHistorico)) {
            foreach ($resultadoHistorico as $key => $value) {
                $SlaSalvo = $value->sla;
                $SlaSalvonum = $value->slanum;
            }
        }



        $ETDFinal = '';
        if (count($resultadoHoraETD) > 0) {


            foreach ($resultadoHoraETD as $key => $value) {

                $ETDFinal = $value->ETD;
                if ($processo == 'planning')
                    $ETDconsiderado = $value->Planning;
                else if ($processo == 'picking')
                    $ETDconsiderado = $value->Picking;
                else if ($processo == 'consolidation')
                    $ETDconsiderado = $value->Consolidation;
                else if ($processo == 'packing')
                    $ETDconsiderado = $value->Packing;
                else if ($processo == 'huclose')
                    $ETDconsiderado = $value->huclose;
                else if ($processo == 'shipping')
                    $ETDconsiderado = $value->Shipping;
            }
        }

        // if ($ETDconsiderado == '00:00')
        //$ETDconsiderado = '23:59:59';


        if (($ETDFinal == '00:00hr' || $ETDFinal == '01:00hr') && $diaNumero == 0)
            $ETDEMSEGUNDOS = strtotime($ETDconsiderado) - strtotime('TODAY') - strtotime('TODAY');
        else
            $ETDEMSEGUNDOS = strtotime($ETDconsiderado) - strtotime('TODAY');

        if (($ETDFinal != '00:00hr' && $ETDFinal != '01:00hr') || $ETDconsiderado == '00:15' || $ETDconsiderado == '00:30' || $ETDconsiderado == '00:00')
            $ETDEMSEGUNDOS =  $ETDEMSEGUNDOS + ($diaNumero  * (3600 * 24));


        $SEGUNDOSATUAL = strtotime(date("H:i:s")) - strtotime('TODAY');

        $statusHoraCorte = '';
        $Stley = '';
        $TotalSegundos = $ETDEMSEGUNDOS - $SEGUNDOSATUAL;
        if ($SEGUNDOSATUAL > $ETDEMSEGUNDOS || $diaNumero == -1) {
            $statusHoraCorte = 'Finalizado';
            $Stley = 'disabled';
            $TotalSegundos = 0;
        } else {

            $statusHoraCorte = floor($TotalSegundos / 3600) . ':' . floor(($TotalSegundos / 60) % 60) . 'hr';
            $Stley = $this->verificaCor($TotalSegundos);
        }

        $remaining_time = new slaatributos;
        $remaining_time->label =  $statusHoraCorte; //mostra tempo para horario de corte
        $remaining_time->style = $Stley;
        $remaining_time->total =  $TotalSegundos;  //total de segundos



        if ($totalPedidos > 0 && $totalPententes > 0) {
            $slaPlanil = round((1 - ($totalPententes / $totalPedidos)) * 100, 2);
        } else {
            $slaPlanil = 100;
        }

        if ($SEGUNDOSATUAL > $ETDEMSEGUNDOS || $diaNumero == -1) {
            $statusHoraCorte = 'Finalizado';
            $Stley = 'disabled';
            $TotalSegundos = 0;
        } else {

            if ($slaPlanil == 100) {
                $Stley = 'success';
            } else {
                $Stley = 'danger';
            }
        }

        $sla = new slaatributos;
        if ($SlaSalvo != '' && $statusHoraCorte == 'Finalizado') {
            $sla->label = $SlaSalvo;
            $sla->slanum = $SlaSalvonum;
        } else {
            $sla->label = $slaPlanil . '%';
            $sla->slanum = $slaPlanil;
        }


        $sla->style = $Stley;
        $sla->total = 10;


        $objPerformace = new slaatributosTodos;
        $objPerformace->sla = $sla;
        $objPerformace->remaining_time = $remaining_time;


        return $objPerformace;
    }

    public function verificaCor($valor)
    {
        if ($valor <= 7200) {
            return 'danger';
        } else if ($valor > 7200 && $valor <= 10800) {
            return 'warning';
        } else {
            return 'success';
        }
    }
}
