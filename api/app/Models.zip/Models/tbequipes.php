<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbequipes extends Model
{
    use HasFactory;
    protected $table = 'tbequipes';
    protected $fillable = [
        'idrep', 'nomerep', 'idle_time', 'time_in_facility', 'total_idle_rep', 'process_time', 'idgestor', 'total_idle_time', 'team_idle_time',
        'average_process_time', 'average_time_in_facility', 'data', 'cad'
    ];
}
