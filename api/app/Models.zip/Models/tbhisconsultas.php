<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbhisconsultas extends Model
{
    use HasFactory;
    protected $table = 'tbhisconsultas';
    protected $fillable = ['processo', 'idrep', 'cad', 'Prodliquida', 'ProdEfetiva', 'Utilizacao', 'unidades', 'Quartil', 'data', 'dia', 'mes', 'ano', 'hora'];

}
