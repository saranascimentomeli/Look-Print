<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ConfigCoresAppsSaturacao extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        
        'nome_regra',
        'condicional_meli_sku_one',
        'quantidade_meli_sku_one',
        'condicional_meli_sku_two',
        'quantidade_meli_sku_two',
        'condicional_saturacao_one',
        'percentual_saturacao_one',
        'condicional_saturacao_two',
        'percentual_saturacao_two',

        'ocultar',
        'hex',
        'user',
        'cad',
    ];
}
