<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class slaperguntas extends Model
{
    use HasFactory;
    protected $table = 'slaperguntas';
    protected $fillable = [
        'id', 'motivo', 'processo', 'cad'
    ];
}
