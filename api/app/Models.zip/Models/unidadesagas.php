<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class unidadesagas extends Model
{
    use HasFactory;
    protected $table = 'unidadesagas';
    protected $fillable = [
        'batch_id', 'group_id', 'inventory_id', 'DataEtd', 'HoraEtd', 'dataEtdCompleta', 'dataAtualizacao',
        'horaAtualizacao', 'dataAtulizacaoCompleta', 'cad'
    ];
}
