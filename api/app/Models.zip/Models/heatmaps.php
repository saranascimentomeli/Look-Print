<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class heatmaps extends Model
{
    use HasFactory;
    protected $table = 'heatmaps';
    protected $fillable = [
        'data', 'time', 'Canalizacao', 'Canal', 'pending', 'planning', 'picking',
        'to_group',
        'grouping', 'to_pack', 'packed', 'to_dispatch', 'to_out', 'out',
        'total', 'totalfeito', 'percentual', 'cad'

    ];
}
