<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbcadpcs extends Model
{
    use HasFactory;
    protected $table = 'tbcadpcs';
    protected $fillable = ['numero', 'ip', 'local', 'setor', 'ultimaAtualizacao'];
}
