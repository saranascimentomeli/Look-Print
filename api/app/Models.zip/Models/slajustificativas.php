<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class slajustificativas extends Model
{
    use HasFactory;
    protected $table = 'slajustificativas';
    protected $fillable = [
        'id', 'idetd', 'ETD', 'processo', 'motivo', 'justificativa', 'usuario', 'datahoje', 'cad'
    ];
}
