<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class inbound_shipment extends Model
{
    use HasFactory;

    protected $fillable = [

        'is_order',
        'fecha_agendada',
        'fecha_chegada',
        'unidades',
        'estado_is',
        'cad'
    ];
}
