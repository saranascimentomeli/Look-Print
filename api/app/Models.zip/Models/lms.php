<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class lms extends Model
{
    use HasFactory;
    protected $table = 'lms';
    protected $fillable = ['idRep', 'Representantes', 'Prodliquida', 'Utilizacao', 'ProdEfetiva', 'Horasdeociosidade', 'Horasemprocesso', 'Horasefetivas', 'unidades', 'data', 'processo', 'cad,', 'HorasdeociosidadeSec', 'HorasemprocessoSec', 'HorasefetivasSec', 'idgertor', 'horaUlAtividade'];




}
