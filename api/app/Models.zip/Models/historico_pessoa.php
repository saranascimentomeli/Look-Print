<?php

namespace App\Models;

use App\config\ConnectionString;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class historico_pessoa extends Model
{
    use HasFactory;
    protected $fillable = ['pessoa', 'flowrack'];

     // protected $connection = ConnectionString::heatmap_shipping;
     protected $connection = 'heatmap';
}
