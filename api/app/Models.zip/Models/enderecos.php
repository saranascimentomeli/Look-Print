<?php

namespace App\Models;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class enderecos extends Model
{
    use HasFactory;

    protected $fillable = [

        'address',
        'area',
        'rua',
        'profundidade',
        'largura',
        'altura',
        'cubagem',
        'disponibilidade',
        'segmento'
    ];

    protected $table = 'sonar_enderecos';

    public static function ImportToDB()
    {
        $path = resource_path('pending-files/*.csv');

        DB::table('sonar_enderecos')->where('cad', '=', Auth::user()->cad)->delete();

        $g = glob($path);

        foreach (array_slice($g, 0, count($g)) as $file) {

            $delimiter = Controller::detectDelimiter($file);

            $data = array_map(function ($v) use ($delimiter) {
                return str_getcsv($v, $delimiter);
            }, file($file));

            foreach ($data as $row) {

                self::insert(

                    [
                        'address' => mb_convert_encoding($row[0], 'UTF-8', 'UTF-8'),

                        'nivel' => substr(mb_convert_encoding($row[0], 'UTF-8', 'UTF-8'), 0, 4),
                        'area' => mb_convert_encoding($row[1], 'UTF-8', 'UTF-8'),
                        'rua' => mb_convert_encoding($row[2], 'UTF-8', 'UTF-8'),
                        'profundidade' => floatval(str_replace(",", ".", mb_convert_encoding($row[3], 'UTF-8', 'UTF-8'))),
                        'largura' => floatval(str_replace(",", ".", mb_convert_encoding($row[4], 'UTF-8', 'UTF-8'))),
                        'altura' => floatval(str_replace(",", ".", mb_convert_encoding($row[5], 'UTF-8', 'UTF-8'))),
                        'cubagem' => floatval(str_replace(",", ".", mb_convert_encoding($row[6], 'UTF-8', 'UTF-8'))),
                        'disponibilidade' => intval(mb_convert_encoding($row[7], 'UTF-8', 'UTF-8')),
                        'segmento' => mb_convert_encoding($row[8], 'UTF-8', 'UTF-8'),
                        'zona' => mb_convert_encoding($row[9], 'UTF-8', 'UTF-8'),
                        'cad' => 1
                        // 'cad' => Auth::user()->cad
                    ]
                );
            }


            unlink($file);
        }
    }
}
