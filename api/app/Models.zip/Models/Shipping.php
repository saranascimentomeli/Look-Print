<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shipping extends Model
{
    use HasFactory;
    protected $table = 'shippings';
    protected $fillable = [
        'IS', 'tipo', 'dataAgendada', 'DataChegada', 'VolumeDeclarado', 'volumeRecebido',
        'volumeRecusado', 'QtdeCodsMl', 'UnidadesNaIS', 'Verdedor', 'StatusIS', 'AtributoIS', 'Nototable', 'Totable',
        'CPG', 'Animales', 'Alimento', 'Cosmetico', 'HV', 'Limpieza', 'Salud', 'cad'
    ];
}
