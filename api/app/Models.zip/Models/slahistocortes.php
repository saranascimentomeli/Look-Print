<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class slahistocortes extends Model
{
    use HasFactory;
    protected $table = 'slahistocortes';
    protected $fillable = [
        'id', 'sla', 'data', 'ETD', 'qtde', 'processo', 'slanum', 'dia', 'mes', 'ano', 'mesdesc', 'cad', 'QtdeTotalPen'
    ];
}
