<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class unidadesaganovos extends Model
{
    use HasFactory;
    protected $table = 'unidadesaganovos';
    protected $fillable = [
        'OrderId', 'BuyDate', 'CreationDate', 'Sla', 'Carrier', 'Type', 'Status', 'StatusupdatedDate', 'InventoryId',
        'Weight', 'Height', 'Width', 'Length', 'Shippeddate', 'Canalization', 'ProcessPath', 'cad'
    ];
}
