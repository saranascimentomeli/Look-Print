<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class stage_put extends Model
{
    use HasFactory;

    protected $fillable = [

        'tote', 
        'cad',
        'stage_by_user',
        'pallet_number',
        'stage',
    ];

    protected $table = 'stage_put';
}
