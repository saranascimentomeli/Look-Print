<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class listapresenca extends Model
{
    use HasFactory;
    protected $table = 'listapresenca';
    protected $fillable = ['idRep','nome', 'turno', 'setor', 'setorarea','nomegestor', 'nomesuper'];


}
