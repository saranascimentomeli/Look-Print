<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class heatmaps_tubos extends Model
{
    use HasFactory;
    protected $table = 'heatmaps_tubos';
    protected $fillable = [
        'tubo', 'canal', 'cad'
    ];
}
