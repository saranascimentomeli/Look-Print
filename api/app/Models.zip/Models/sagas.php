<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sagas extends Model
{
    use HasFactory;
    protected $table = 'sagas';
    protected $fillable = [
        'UnitLoadId', 'Manager', 'Status', 'InitialPosition', 'OriginPosition', 'CurrentPositionId', 'NextPositionId',
        'DestinationPositionId', 'NumberOfRounds', 'StartDate', 'EndDate', 'LastChange', 'LastStatusChange', 'cad'
    ];
}
