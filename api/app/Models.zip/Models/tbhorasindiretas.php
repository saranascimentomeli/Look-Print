<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tbhorasindiretas extends Model
{
    use HasFactory;
    protected $table = 'tbhorasindiretas';
    protected $fillable = [
        'idrep', 'nomerep', 'rep_type', 'utilization', 'effective_productivity', 'iddle_time', 'proccess_time', 'effective_time',
        'net_productivity', 'unit_count', 'is_iddle', 'idgestor', 'tipoprocesso', 'data', 'cad'
    ];
}
