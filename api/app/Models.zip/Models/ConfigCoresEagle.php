<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConfigCoresEagle extends Model
{
    use HasFactory;

    protected $fillable = [

        'nomeRegra',
        'tempo_minimo',
        'condicional_tempo_minimo',
        'tempo_maximo',
        'condicional_tempo_maximo',
        'color_hex',
        'responsavel',
        'cad',
        'ordem_da_regra',
    ];
}
