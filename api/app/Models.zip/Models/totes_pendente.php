<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class totes_pendente extends Model
{
    use HasFactory;

    protected $fillable = [
        'tote',
        'processo_pendente',
        'is_order',
        'cad'    
    ];
}
